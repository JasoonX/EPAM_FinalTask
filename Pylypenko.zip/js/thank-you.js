"use strict";
document.querySelector(".basket p").innerText = "Basket (0)";
